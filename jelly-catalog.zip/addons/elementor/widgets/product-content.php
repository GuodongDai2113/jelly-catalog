<?php
namespace Jelly_Catalog\Addons\Elementor\Widgets;

use ElementorPro\Modules\ThemeBuilder\Widgets\Post_Content;
use ElementorPro\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Product_Content extends Post_Content {

	public function get_name() {
		return 'jc-product-content';
	}

	public function get_title() {
		return esc_html__( 'Product Content', 'elementor-pro' );
	}

	public function get_categories() {
		return [ 'jc-elements-single' ];
	}

	public function get_keywords() {
		return [ 'content', 'post', 'product' ];
	}

	public function get_group_name() {
		return 'jelly';
	}

	public function has_widget_inner_wrapper(): bool {
		return ! Plugin::elementor()->experiments->is_feature_active( 'e_optimized_markup' );
	}
}
